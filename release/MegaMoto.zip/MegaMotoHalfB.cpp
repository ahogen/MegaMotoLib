/********************************************//**
 * \file     MegaMotoHalfB.cpp
 * \author   Alexander Hogen
 * \date     1/3/2017
 * \version  0.1
 * \brief    Contains the definitions for all the
 *           member methods of the MegaMotoHalfB
 *           class.
 *
 * Released into the public domain.
 *
 ***********************************************/

#include "MegaMotoHalfB.h"