var searchData=
[
  ['megamotobase',['MegaMotoBase',['../class_mega_moto_base.html#a3fd97ea1af471e6d70e548aee7905229',1,'MegaMotoBase::MegaMotoBase(unsigned char pin_pwm_a, unsigned char pin_pwm_b)'],['../class_mega_moto_base.html#a6c01d5a7b455821cae4e2018dc7530a5',1,'MegaMotoBase::MegaMotoBase(unsigned char pin_pwm_a, unsigned char pin_pwm_b, unsigned char pin_enable)']]],
  ['megamotohb',['MegaMotoHB',['../class_mega_moto_h_b.html#a26703c87f311208f87129c73bc8b20b2',1,'MegaMotoHB::MegaMotoHB(unsigned char pin_pwm_a, unsigned char pin_pwm_b)'],['../class_mega_moto_h_b.html#a3cfb3448469f5d356b9995421ccff5a6',1,'MegaMotoHB::MegaMotoHB(char pin_pwm_a, char pin_pwm_b, char pin_enable)']]]
];
